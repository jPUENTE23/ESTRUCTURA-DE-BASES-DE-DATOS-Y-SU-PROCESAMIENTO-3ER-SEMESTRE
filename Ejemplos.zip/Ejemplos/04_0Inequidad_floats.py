#Comprobar inexactitud de los float
i = 0.0
while i != 1.0:
    print(f"i ={i}")
    i = i + 0.1


